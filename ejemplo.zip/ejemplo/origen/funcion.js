(algo)=>{
 console.log("Desde Algo:", algo);
}